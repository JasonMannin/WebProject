<!--header describes what happens on the page-->
<h2>Highest Searched Films</h2>

<?php
/**
 * inc_top10content contains the code to select the top 10 highest searched movies from the database table 
 * and display them in a table on the top10.php page
 * 
 * @category DiplomaAssessments
 * @package  Project
 * @author   Jason Mannin <30000876@tafe.wa.edu.au>
 * @license  http://www.php.net/license/3_01.txt  PHP License 3.01
 * @link     http://pear.php.net/package/Project
PHP Version 5
 */
    require "connect.php";
    //sql statement to select the top 10 highest searched films
    //uses search column which increments whenever a movie is selected by the search select statement
    //orders the movies in descending order by that value
    //and limits to 10 results
    $sql = "SELECT title, year, genre, rating, search
            FROM movies
            ORDER BY search DESC
            LIMIT 10";
    $result = $conn->query($sql);

//if there are more than 0 results, create the table and display
if ($result->num_rows > 0) {
        echo '<table class = "table" id = "t10">';
        echo "<tr>
            <th>Title</th>
            <th>Genre</th>
            <th>Rating</th>
            <th>Release Year</th>
            <th>Times Searched</th>
            </tr>";

    //display database table data in the table on the top10.php page
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
            <td>" . $row["title"]. "</td>
            <td>" . $row["genre"]. "</td>
            <td>" . $row["rating"]. "</td>
            <td>" . $row["year"]. "</td>
            <td>" . $row["search"]. "</td>
        </tr>";
    }
        echo "</table>";
} else {
    //if there are 0 results display user friendly message
    echo "<h3>Sorry, there appear to be no films in the database that have been searched yet. I wonder what film will be the first.</h3>";
}
$conn->close();
?>
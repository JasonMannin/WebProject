<!--header describes what the page shows-->
<h2>Film Of The Day</h2>

<?php
/**
 * inc_homecontent.php contains the random select sql statement that is used to populate the table on the 
 * home page of the website
 * 
 * @category DiplomaAssessments
 * @package  Project
 * @author   Jason Mannin <30000876@tafe.wa.edu.au>
 * @license  http://www.php.net/license/3_01.txt  PHP License 3.01
 * @link     http://pear.php.net/package/Project
PHP Version 5
 */
    require "connect.php";
    //sql statement to select 1 random movie from the table
    $sql = "SELECT title, year, genre, rating
            FROM movies
            ORDER BY RAND()
            LIMIT 1";
    $result = $conn->query($sql);

    $row = $result->fetch_assoc();

    //echo table to page with id "tData" to allow for css styling
    echo '<table class = "table" id = "tData">';

    //echo table header rows
    echo "<tr>
            <th>Title</th>
            <th>Genre</th>
            <th>Rating</th>
            <th>Release Year</th>
        </tr>";

    //echo table data rows using $row to grab the database data and display it in the table
    echo "<tr>
            <td>" . $row["title"]. "</td>
            <td>" . $row["genre"]. "</td>
            <td>" . $row["rating"]. "</td>
            <td>" . $row["year"]. "</td>
        </tr>";
?>
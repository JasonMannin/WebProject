<!--inc_nav contains the navigation menu text and the links to the pages they go to
this is called in the other main .php files-->
<ul class="nav">
 <li><a href="index.php">HOME</a></li>
 <li><a href="search.php">SEARCH</a></li>
 <li><a href="top10.php">TOP 10</a></li>
</ul>

<!--inc_logo contains the information about the logo image and is called in the main .php files-->
<a href = "index.php"><img src = "/images/SMTLogo.png" id = "Logo" /></a>
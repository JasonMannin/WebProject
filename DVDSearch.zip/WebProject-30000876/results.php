<!DOCTYPE html>
<html lang = "en">
    <head>
        <title>
            <?php 
            /**
             * results.php contains the results of the search, and is only accessible through the search page
             * 
             * @category DiplomaAssessments
             * @package  Project
             * @author   Jason Mannin <30000876@tafe.wa.edu.au>
             * @license  http://www.php.net/license/3_01.txt  PHP License 3.01
             * @link     http://pear.php.net/package/Project
            PHP Version 5
             */
            echo basename(__FILE__, '.php'); ?>
        </title>
        <meta charset = "UTF-8">
        <link rel = "stylesheet" type = "text/css" href = "css/style.css"/>
    </head>

    <body>
        <!--background image div-->
        <div class = "bg-image"></div>

        <!--banner div, includes banner css styling and text-->
        <div id = "banner">
            <h1>SMT - Results</h1>
        </div>

        <!--logo div, logo image placed in top left corner
            logo is link to index.php-->
        <div id = "logo">
            <a href = "index.php"><img src = "/images/SMTLogo.png" alt = "Logo" id = "Logo" align = "left" width = "200px"/></a>
        </div>

        <!--container div stores all the main content of the page-->
        <div id="container">
            <!--navbar div requires inc_nav and allows css styling of nav bar-->
            <div id="navbar">
                <?php
                    require_once 'include/inc_nav.php';
                ?>
            </div>

            <!--content div requires searchmovie_scr and contains the main content in the body
            this is where the search results are gathered and displayed-->
            <div class="content">
                <?php
                    require_once 'searchmovie_scr.php';
                ?>
            </div>
            <!--footer div requires inc_footer and contains the footer-->
            <div class="footer">
                <?php 
                    require_once 'include/inc_footer.html';
                ?>
            </div>
        </div>
    </body>
</html>
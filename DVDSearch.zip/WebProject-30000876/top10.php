<!DOCTYPE html>
<html lang = "en">
    <head>
        <title>
            <?php 
            /**
             * top10.php contains a table which shows the highest searched movies from the database table by using
             * a search column value and ordering in descending order
             * 
             * @category DiplomaAssessments
             * @package  Project
             * @author   Jason Mannin <30000876@tafe.wa.edu.au>
             * @license  http://www.php.net/license/3_01.txt  PHP License 3.01
             * @link     http://pear.php.net/package/Project
            PHP Version 5
             */
            echo basename(__FILE__, '.php'); ?>
        </title>
        <meta charset = "UTF-8">
        <link rel = "stylesheet" type = "text/css" href = "css/style.css"/>
    </head>

    <body>
        <!--background image div-->
        <div class = "bg-image"></div>

        <!--banner div, includes banner css styling and text-->
        <div id = "banner">
            <h1>SMT - Top 10</h1>
        </div>

        <!--logo div, logo image placed in top left corner
            logo is link to index.php-->
        <div id = "logo">
            <a href = "index.php"><img src = "/images/SMTLogo.png" alt = "Logo" id = "Logo" align = "left" width = "200px"/></a>
        </div>

        <!--container div stores all the main content of the page-->
        <div id="container">
            <!--navbar div requires inc_nav and allows css styling of nav bar-->
            <div id="navbar">
                <?php
                    require_once 'include/inc_nav.php';
                ?>
            </div>

            <!--content div requires inc_top10content and contains the main content in the body-->
            <div class="content">
                <?php
                    require_once 'include/inc_top10content.php';
                ?>
            </div>
            <!--footer div requires inc_footer and contains the footer-->
            <div class="footer">
                <?php 
                    require_once 'include/inc_footer.html';
                ?>
            </div>
        </div>
    </body>
</html>
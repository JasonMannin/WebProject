<?php
/**
 * Script to search database table for movies based on information given in form fields
 * 
 * @category DiplomaAssessments
 * @package  Project
 * @author   Jason Mannin <30000876@tafe.wa.edu.au>
 * @license  http://www.php.net/license/3_01.txt  PHP License 3.01
 * @link     http://pear.php.net/package/Project
PHP Version 5
 */
require "connect.php";

//store data from form into variables
$title = $_POST["title"];
$genre = $_POST["genre"];
$rating = $_POST["rating"];
$year = $_POST["year"];

//if the form is empty, display error message
if (empty($title) && empty($genre) && empty($rating) && empty($year)) {
    echo "<h3>You have not entered any valid information into the search fields. Please try again.</h3>";
//else begin series of if statements which cover each possible input user could enter
//if any field has data, continue
} else if (!empty($title) || !empty($genre) || !empty($rating) || !empty($year)) {
    //if all 4 fields have data, select using $sql, then increment search value in table using $sqlUpdate
    //doing the 4 field select first, then 3 field combinations, then 2 field, then 1 field
    //prevents missed searching
    if (!empty($title) && !empty($genre) && !empty($rating) && !empty($year)) {
        $sql = "SELECT title, genre, rating, year, studio, status, sound, versions, aspect, search
                FROM movies
                WHERE title LIKE '%$title%' AND genre LIKE '%$genre%' AND rating = '$rating' AND year = '$year'
                ORDER BY id ASC";
        $result = $conn->query($sql);
        $sqlUpdate = "UPDATE movies
                        SET search = search + 1
                        WHERE title LIKE '%$title%' AND genre LIKE '%$genre%' AND rating = '$rating' AND year = '$year'";
        $resultUpdate = $conn->query($sqlUpdate);
    //if title, genre, and rating have data, select using $sql, then increment search value in table using $sqlUpdate
    } else if (!empty($title) && !empty($genre) && !empty($rating)) {
        $sql = "SELECT title, genre, rating, year, studio, status, sound, versions, aspect, search
                FROM movies
                WHERE title LIKE '%$title%' AND genre LIKE '%$genre%' AND rating = '$rating'
                ORDER BY id ASC";
        $result = $conn->query($sql);
        $sqlUpdate = "UPDATE movies
                        SET search = search + 1
                        WHERE title LIKE '%$title%' AND genre LIKE '%$genre%' AND rating = '$rating'";
        $resultUpdate = $conn->query($sqlUpdate);
    //if title, genre, and year have data, select using $sql, then increment search value in table using $sqlUpdate
    } else if (!empty($title) && !empty($genre) && !empty($year)) {
        $sql = "SELECT title, genre, rating, year, studio, status, sound, versions, aspect, search
                FROM movies
                WHERE title LIKE '%$title%' AND genre LIKE '%$genre%' AND year = '$year'
                ORDER BY id ASC";
        $result = $conn->query($sql);
        $sqlUpdate = "UPDATE movies
                        SET search = search + 1
                        WHERE title LIKE '%$title%' AND genre LIKE '%$genre%' AND year = '$year'";
        $resultUpdate = $conn->query($sqlUpdate);
    //if title, rating, and year have data, select using $sql, then increment search value in table using $sqlUpdate
    } else if (!empty($title) && !empty($rating) && !empty($year)) {
        $sql = "SELECT title, genre, rating, year, studio, status, sound, versions, aspect, search
                FROM movies
                WHERE title LIKE '%$title%' AND rating = '$rating' AND year = '$year'
                ORDER BY id ASC";
        $result = $conn->query($sql);
        $sqlUpdate = "UPDATE movies
                        SET search = search + 1
                        WHERE title LIKE '%$title%' AND rating = '$rating' AND year = '$year'";
        $resultUpdate = $conn->query($sqlUpdate);
    //if genre, rating and year have data, select using $sql, then increment search value in table using $sqlUpdate
    } else if (!empty($genre) && !empty($rating) && !empty($year)) {
        $sql = "SELECT title, genre, rating, year, studio, status, sound, versions, aspect, search
                FROM movies
                WHERE genre LIKE '%$genre%' AND rating = '$rating' AND year = '$year'
                ORDER BY id ASC";
        $result = $conn->query($sql);
        $sqlUpdate = "UPDATE movies
                        SET search = search + 1
                        WHERE genre LIKE '%$genre%' AND rating = '$rating' AND year = '$year'";
        $resultUpdate = $conn->query($sqlUpdate);
    //if title and genre have data, select using $sql, then increment search value in table using $sqlUpdate
    } else if (!empty($title) && !empty($genre)) {
        $sql = "SELECT title, genre, rating, year, studio, status, sound, versions, aspect, search
                FROM movies
                WHERE title LIKE '%$title%' AND genre LIKE '%$genre%'
                ORDER BY id ASC";
        $result = $conn->query($sql);
        $sqlUpdate = "UPDATE movies
                        SET search = search + 1
                        WHERE title LIKE '%$title%' AND genre LIKE '%$genre%'";
        $resultUpdate = $conn->query($sqlUpdate);
    //if title and rating have data, select using $sql, then increment search value in table using $sqlUpdate
    } else if (!empty($title) && !empty($rating)) {
        $sql = "SELECT title, genre, rating, year, studio, status, sound, versions, aspect, search
                FROM movies
                WHERE title LIKE '%$title%' AND rating = '$rating'
                ORDER BY id ASC";
        $result = $conn->query($sql);
        $sqlUpdate = "UPDATE movies
                        SET search = search + 1
                        WHERE title LIKE '%$title%' AND rating = '$rating'";
        $resultUpdate = $conn->query($sqlUpdate);
    //if title and year have data, select using $sql, then increment search value in table using $sqlUpdate
    } else if (!empty($title) && !empty($year)) {
        $sql = "SELECT title, genre, rating, year, studio, status, sound, versions, aspect, search
                FROM movies
                WHERE title LIKE '%$title%' AND year = '$year'
                ORDER BY id ASC";
        $result = $conn->query($sql);
        $sqlUpdate = "UPDATE movies
                        SET search = search + 1
                        WHERE title LIKE '%$title%' AND year = '$year'";
        $resultUpdate = $conn->query($sqlUpdate);
    //if genre and rating have data, select using $sql, then increment search value in table using $sqlUpdate
    } else if (!empty($genre) && !empty($rating)) {
        $sql = "SELECT title, genre, rating, year, studio, status, sound, versions, aspect, search
                FROM movies
                WHERE genre LIKE '%$genre%' AND rating = '$rating'
                ORDER BY id ASC";
        $result = $conn->query($sql);
        $sqlUpdate = "UPDATE movies
                        SET search = search + 1
                        WHERE genre LIKE '%$genre%' AND rating = '$rating'";
        $resultUpdate = $conn->query($sqlUpdate);
    //if genre and year have data, select using $sql, then increment search value in table using $sqlUpdate
    } else if (!empty($genre) && !empty($year)) {
        $sql = "SELECT title, genre, rating, year, studio, status, sound, versions, aspect, search
                FROM movies
                WHERE genre LIKE '%$genre%' AND year = '$year'
                ORDER BY id ASC";
        $result = $conn->query($sql);
        $sqlUpdate = "UPDATE movies
                        SET search = search + 1
                        WHERE genre LIKE '%$genre%' AND year = '$year'";
        $resultUpdate = $conn->query($sqlUpdate);
    //if rating and year have data, select using $sql, then increment search value in table using $sqlUpdate
    } else if (!empty($rating) && !empty($year)) {
        $sql = "SELECT title, genre, rating, year, studio, status, sound, versions, aspect, search
                FROM movies
                WHERE rating = '$rating' AND year = '$year'
                ORDER BY id ASC";
        $result = $conn->query($sql);
        $sqlUpdate = "UPDATE movies
                        SET search = search + 1
                        WHERE rating = '$rating' AND year = '$year'";
        $resultUpdate = $conn->query($sqlUpdate);
    //if only title has data, select using $sql, then increment search value in table using $sqlUpdate
    } else if (!empty($title)) {
        $sql = "SELECT title, genre, rating, year, studio, status, sound, versions, aspect, search
                FROM movies
                WHERE title LIKE '%$title%'
                ORDER BY id ASC";
        $result = $conn->query($sql);
        $sqlUpdate = "UPDATE movies
                        SET search = search + 1
                        WHERE title LIKE '%$title%'";
        $resultUpdate = $conn->query($sqlUpdate);
    //if only genre has data, select using $sql, then increment search value in table using $sqlUpdate
    } else if (!empty($genre)) {
        $sql = "SELECT title, genre, rating, year, studio, status, sound, versions, aspect, search
                FROM movies
                WHERE genre LIKE '%$genre%'
                ORDER BY id ASC";
        $result = $conn->query($sql);
        $sqlUpdate = "UPDATE movies
                        SET search = search + 1
                        WHERE genre LIKE '%$genre%";
        $resultUpdate = $conn->query($sqlUpdate);
    //if only rating has data, select using $sql, then increment search value in table using $sqlUpdate
    } else if (!empty($rating)) {
        $sql = "SELECT title, genre, rating, year, studio, status, sound, versions, aspect, search
                FROM movies
                WHERE rating = '$rating'
                ORDER BY id ASC";
        $result = $conn->query($sql);
        $sqlUpdate = "UPDATE movies
                        SET search = search + 1
                        WHERE rating = '$rating'";
        $resultUpdate = $conn->query($sqlUpdate);
    //if only year has data, select using $sql, then increment search value in table using $sqlUpdate
    } else if (!empty($year)) {
        $sql = "SELECT title, genre, rating, year, studio, status, sound, versions, aspect, search
                FROM movies
                WHERE year = '$year'
                ORDER BY id ASC";
        $result = $conn->query($sql);
        $sqlUpdate = "UPDATE movies
                        SET search = search + 1
                        WHERE year = '$year'";
        $resultUpdate = $conn->query($sqlUpdate);
    }

    //create $found variable to store amount of reults found
    $found = $result->num_rows;

    //if results is > 0, print number of results found
    //then print table
    if ($found > 0) {
        echo "<h3>$found" .  " Results Found.</h3>";
        echo '<table class = "table" id = "search">';
        echo "<tr>
            <th>Title</th>
            <th>Genre</th>
            <th>Rating</th>
            <th>Release Year</th>
            <th>Studio</th>
            <th>Status</th>
            <th>Sound</th>
            <th>Versions</th>
            <th>Aspect</th>
            </tr>";

        //print table row data in while loop
        while ($row = $result->fetch_assoc()) {
            echo "<tr>
                <td>" . $row["title"]. "</td>
                <td>" . $row["genre"]. "</td>
                <td>" . $row["rating"]. "</td>
                <td>" . $row["year"]. "</td>
                <td>" . $row["studio"]. "</td>
                <td>" . $row["status"]. "</td>
                <td>" . $row["sound"]. "</td>
                <td>" . $row["versions"]. "</td>
                <td>" . $row["aspect"]. "</td>
            </tr>";
        }
        echo "</table>";
    } else {
        //if there are 0 results, print error message to user
        echo "<h3>Sorry, there appear to be no films in the database that match your search criteria. Please try again.</h3>";
    }
}
$conn->close();
?>